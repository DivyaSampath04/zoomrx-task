import logo from './logo.svg';
import './App.css';
import Entry from './container/Entry';

function App() {
  return (
    <div className="App">
    <Entry />
    </div>
  );
}

export default App;
