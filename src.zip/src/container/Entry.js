import React from "react";
import {
  BrowserRouter,
  Router,
  Switch,
  Route,
  withRouter,
} from "react-router-dom";
import Lists from "../components/Lists/Lists";
import EachCard from "../components/Lists/EachList/Cards/EachCard/EachCard";
import { Divider } from "@material-ui/core";
// tried to bring in card details in seperate page using router.
class Entry extends React.Component {
  state = {
    card_name: "",
    list_name: "",
    all_cards: "",
    modal: "",
  };
  handlePageChange = (card_info, list_info, all_cards, modal) => {
    this.setState({
      card_name: card_info,
      list_name: list_info,
      all_cards: all_cards,
      modal: modal,
    });
  };
  render() {
    return (
      <>
        <p className="page-title">PERSONAL TASK MANAGER</p>
        <br />
        <Divider />

       <Lists />
      </>
    );
  }
}

export default Entry;
