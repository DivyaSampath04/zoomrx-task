import React from "react";
import "./EachList.css";
import EditIcon from "@material-ui/icons/Edit";
import DeleteIcon from "@material-ui/icons/Delete";
import CheckIcon from "@material-ui/icons/Check";
import ClearIcon from "@material-ui/icons/Clear";
import { TextField, Button, IconButton, Icon } from "@material-ui/core";
import Cards from "./Cards/Cards";
import EachCard from "./Cards/EachCard/EachCard";
import DeleteOutlineOutlinedIcon from "@material-ui/icons/DeleteOutlineOutlined";

class EachList extends React.Component {
  state = {
    isAdd: "",
  };
  closeAdd = () => {
    this.setState({ isAdd: "" });
  };
  render() {
    let cards = this.props.list_info[1].cards
      ? Object.entries(this.props.list_info[1].cards)
      : null;
  
    return (
      <>
        <div className="each-list">
          <div className="list-content">
            <div className="list-title">
              {this.props.edit_list &&
              this.props.edit_list === true &&
              this.props.list_info &&
              this.props.list_info[1].listTitle === this.props.list_id ? (
                <>
                  <TextField
                    // label =  'List Title'
                    autoComplete="off"
                    value={this.props.list_title}
                    name="list_title"
                    onChange={(event) => this.props.handleChange(event)}
                  />
                  <div>
                    <CheckIcon
                      fontSize="small"
                      color="primary"
                      onClick={() =>
                        this.props.save("list", "edit", this.props.list_info[0])
                      }
                    />

                    <ClearIcon
                      onClick={() =>
                        this.props.cancelEdit(this.props.list_id, "edit")
                      }
                      fontSize="small"
                    />
                  </div>
                </>
              ) : (
                <>
                  <p style={{ color: "grey" }}>
                    {this.props.list_info[1].listTitle}
                  </p>
                  <div>
                    <EditIcon
                      onClick={() =>
                        this.props.editList(this.props.list_info[1].listTitle)
                      }
                      fontSize="small"
                      color="primary"
                    />

                    <DeleteOutlineOutlinedIcon
                      onClick={() =>
                        this.props.delete("list", this.props.list_info[0])
                      }
                      fontSize="small"
                    />
                  </div>
                </>
              )}
            </div>
            {cards ?
              cards.map((card, i) => 
                <Cards
               
                  card={card}
                  list_title={this.props.list_info[1].listTitle}
                
                  all_cards={Object.entries(this.props.list_info[1].cards)}
                  isAdd={this.state.isAdd}
                  deleteCard={this.props.delete}
                  saveCard={this.props.save}
                  list_id={this.props.list_info}
                  closeAdd={this.closeAdd}
                />
              ) :
              <EachCard 
              isAdd = {this.state.isAdd}
              saveCard={this.props.save}
              list_id={this.props.list_info}
              closeAdd={this.closeAdd}/>}
            <div>
              <Button
                variant="outlined"
                onClick={() => this.setState({ isAdd: true })}
              >
                Add New Card
              </Button>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default EachList;
