import React from "react";
import "./EachCard.css";
import {
  Button,
  TextField,
  TextareaAutosize,
  Dialog,
  DialogContent,
  IconButton,
} from "@material-ui/core";
import ClearIcon from "@material-ui/icons/Clear";
import EditIcon from "@material-ui/icons/Edit";
import DeleteIcon from "@material-ui/icons/Delete";
import CheckIcon from "@material-ui/icons/Check";


class EachCard extends React.Component {
  state = {
    card_desc: "",
    card_title: "",
  };
  handleChange = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  };
  render() {
   
    return (
      <>
        <Dialog
          open={
            this.props.isAdd === true ||
            this.props.modal === "view" ||
            this.props.modal === "edit"
          }
        >
          <DialogContent>
            <div className="card-details">
              {this.props.isAdd === true ? (
                <div>
                  <div className="flex-row">
                    <div className="card-heading">
                      <TextField
                        label="Card title"
                        value={this.state.card_title}
                        name="card_title"
                        onChange={(event) => this.handleChange(event)}
                      />
                    </div>
                    <div className="card-heading">
                      <IconButton
                        onClick={() => {
                          this.props.saveCard(
                            "card",
                            "add",
                            this.props.list_id,
                            this.state
                          );
                          this.props.closeAdd();
                        }}
                      >
                        <CheckIcon fontSize="small" color="primary" />
                      </IconButton>
                      <IconButton onClick={this.props.closeAdd}>
                        <ClearIcon fontSize="small" />
                      </IconButton>
                    </div>
                  </div>
                  <div className="card-desc">
                    <TextareaAutosize
                      className="text-area"
                      rowsMin={3}
                      placeholder="Enter Description of Card"
                      value={this.state.card_desc}
                      name="card_desc"
                      onChange={(event) => this.handleChange(event)}
                    />
                  </div>
                </div>
              ) : (
                <>
                  {this.props.modal && this.props.modal === "edit" ? (
                    <>
                      <div className="flex-row">
                        <div className="card-heading">
                          <TextField
                            label="Card title"
                            value={this.state.card_title}
                            name="card_title"
                            onChange={(event) => this.handleChange(event)}
                          />
                        </div>
                        <div className="card-heading">
                          <IconButton
                            onClick={() => {
                              this.props.saveCard(
                                "card",
                                "edit",
                                this.props.list_name,
                                this.props.card_id,
                                this.state
                              );
                              this.props.closeDialog();
                            }}
                          >
                            <CheckIcon color="primary" fontSize="small" />
                          </IconButton>
                          <IconButton onClick={this.props.closeDialog}>
                            <ClearIcon fontSize="small" />
                          </IconButton>
                        </div>
                      </div>
                      <div className="card-desc">
                        <TextareaAutosize
                          className="text-area"
                          rowsMin={3}
                          placeholder="Enter Description of Card"
                          value={this.state.card_desc}
                          name="card_desc"
                          onChange={(event) => this.handleChange(event)}
                        />
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="flex-row">
                        <div className="card-desc">
                          <p
                            style={{ fontWeight: "500", marginBottom: "10px" }}
                          >
                            Title
                          </p>
                          <div className="card-heading">
                            <p>{this.props.card_name}</p>
                          </div>
                        </div>

                        <div>
                          <IconButton onClick={() => this.props.editCard()}>
                            <EditIcon color="primary" fontSize="small" />
                          </IconButton>
                          <IconButton>
                            <DeleteIcon
                              onClick={() =>{
                                this.props.deleteCard(
                                  "card",
                                  this.props.list_name,
                                  this.props.card_id
                                );
                                this.props.closeDialog();}
                              }
                              fontSize="small"
                            />
                          </IconButton>
                          <Button
                            variant="outlined"
                            onClick={this.props.closeDialog}
                          >
                            {" "}
                            Close
                          </Button>
                        </div>
                      </div>
                      <div className="card-desc">
                        <p style={{ fontWeight: "500", marginBottom: "10px" }}>
                          Description
                        </p>
                        {this.props.all_cards &&
                          this.props.all_cards.map(
                            (card, i) =>
                              card[0] === this.props.card_id && (
                                <p>{card[1].description} </p>
                              )
                          )}
                      </div>
                    </>
                  )}
                </>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </>
    );
  }
}

export default EachCard;
