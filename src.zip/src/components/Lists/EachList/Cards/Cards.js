import React from "react";
import "./Cards.css";

import EachCard from "./EachCard/EachCard";

class Cards extends React.Component {
  state = {
    card_name: "",
    list_name: "",
    all_cards: "",
    modal: "",
    edit_flag: "",
    card_id: "",
  };
  handleDialog = (card_id, card_info, list_info, all_cards, modal) => {
    this.setState({
      card_name: card_info,
      list_name: list_info,
      all_cards: all_cards,
      modal: modal,
      card_id: card_id,
    });
  };
  closeDialog = () => {
    this.setState({ modal: "close" });
  };
  editCard = () => {
    this.setState({ modal: "edit" });
  };
  render() {
   
    return (
      <>
        <div
          className="each-card" draggable = 'true'
          onClick={() =>
            this.handleDialog(
              this.props.card[0],
              this.props.card[1].title,
              this.props.list_title,
              this.props.all_cards,
              "view"
            )
          }
        >
          <p className="card-title">{this.props.card[1].title}</p>
          <div>
            <p style={{ fontWeight: "300" }}>Click to view more...</p>
          </div>
        </div>

        <EachCard
          card_name={this.state.card_name}
          list_name={this.state.list_name}
          all_cards={this.state.all_cards}
          modal={this.state.modal}
          closeDialog={this.closeDialog}
          editCard={this.editCard}
          edit_flag={this.state.edit_flag}
          isAdd={this.props.isAdd}
          deleteCard={this.props.deleteCard}
          saveCard={this.props.saveCard}
          card_id={this.state.card_id}
          list_id={this.props.list_id}
          closeAdd={this.props.closeAdd}
        />
      </>
    );
  }
}
export default Cards;
