import React from "react";
import * as c from "../../config/config";
import EachList from "./EachList/EachList";
import "./Lists.css";
import CheckIcon from "@material-ui/icons/Check";
import ClearIcon from "@material-ui/icons/Clear";
import { TextField, Button } from "@material-ui/core";

class List extends React.Component {
  state = {
    my_lists: "",
    list_title: "",
    edit_list: "",
    list_id: "",
    add_list: "",
  };
  componentDidMount = () => {
    this.setState({ my_lists: c.ALL_TASK });
  };
  handleChange = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  };
  //Save the item..item can be list or card
  save = (item, modal, key1, key2, key3) => {
 
    if (item === "list") {
      if (modal === "add") {
        this.state.my_lists[key1] = {
          listTitle: this.state.list_title,
        };
        this.setState({
          add_list: false,
          edit_list: false,
          my_lists: this.state.my_lists,
        });
      } else {
        for (var i = 0; i < Object.entries(this.state.my_lists).length; i++) {
          if (Object.entries(this.state.my_lists)[i][0] === key1) {
            this.state.my_lists[key1].listTitle = this.state.list_title;
          }
        }
        this.setState({
          add_list: false,
          edit_list: false,
          my_lists: this.state.my_lists,
        });
      }
    } else if (item === "card") {
      if (modal === "edit") {
        for (var i = 0; i < Object.keys(this.state.my_lists).length; i++) {
          if (Object.values(this.state.my_lists)[i].listTitle === key1) {
            Object.entries(this.state.my_lists)[i][1].cards[key2].title =
              key3.card_title;
            Object.entries(this.state.my_lists)[i][1].cards[key2].description =
              key3.card_desc;
          }
        }
      } else if (modal === "add") {
        if(this.state.my_lists[key1[0]].cards){
        this.state.my_lists[key1[0]].cards[key2.card_title] = {
          title: key2.card_title,
          description: key2.card_desc,
        };
      }
      else{
        this.state.my_lists[key1[0]]['cards'] = {
          'card 1' : {
       
              'title' : key2.card_title,
              'description' : key2.card_desc
          }
          };
          
        }
      
      }
      this.setState({ my_lists: this.state.my_lists });
    }
  };

  addList = () => {
    this.setState({ add_list: true, list_title: "", edit_list: false });
  };
  editList = (title) => {
    this.setState({ edit_list: true, list_id: title, list_title: title });
  };
  cancelEdit = (key, modal) => {
    if (modal === "edit") {
      if (key === this.state.list_id) this.setState({ edit_list: false });
    } else this.setState({ add_list: false });
  };
  //Deletes the item.. item can be list or card
  delete = (item, key1, key2) => {
    //delete selecetd list
    if (item === "list") {
      delete this.state.my_lists[key1];
    }
    //delete selected card
    else if (item === "card") {
      for (var i = 0; i < Object.keys(this.state.my_lists).length; i++) {
        if (Object.values(this.state.my_lists)[i].listTitle === key1) {
          delete this.state.my_lists[Object.keys(this.state.my_lists)[i]].cards[
            key2
          ];
        }
      }
    }
    this.setState({ my_lists: this.state.my_lists });
  };

 
  render() {
    let my_lists = this.state.my_lists
      ? Object.entries(this.state.my_lists)
      : "";

    return (
      <div className="all-lists">
        {my_lists &&
          my_lists.map((list, i) => (
            <EachList
              list_id={this.state.list_id}
              list_title={this.state.list_title}
              list_info={list}
              editList={this.editList}
              edit_list={this.state.edit_list}
              save={this.save}
              add_list={this.state.add_list}
              cancelEdit={this.cancelEdit}
              handleChange={this.handleChange}
              delete={this.delete}
             
            />
          ))}

        {this.state.add_list && this.state.add_list === true && (
          <div className="each-list">
            <div className="list-content">
              <div className="list-title">
                <TextField
                  label="List Title"
                  value={this.state.list_title}
                  name="list_title"
                  onChange={(event) => this.handleChange(event)}
                  autoComplete="off"
                />
                <div className="action-icons">
                  <CheckIcon
                    fontSize="small"
                    color="primary"
                    onClick={() =>
                      this.save("list", "add", this.state.list_title)
                    }
                  />
                  <ClearIcon
                    fontSize="small"
                    color="primary"
                    onClick={() =>
                      this.cancelEdit(this.state.list_title, "add")
                    }
                  />
                </div>
              </div>
            </div>
          </div>
        )}
        <div>
          <Button onClick={this.addList} variant="outlined">
            Add New List
          </Button>
        </div>
      </div>
    );
  }
}

export default List;
