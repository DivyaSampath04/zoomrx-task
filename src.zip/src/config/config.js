export const ALL_TASK = {
    
        'list1' : {
            'listTitle' : 'WORK',
             'cards' : {
                 'card 1' : {
                     'title' : 'Stand up call',
                     'description' : 'Plan tasks for next sprint'
                 },
                 'card 2' : {
                    'title' : 'Appraisal discussion',
                    'description' : 'List out key areas for the quarter'
                 },
                 'card 3' : {
                    'title' : 'Design project architecture',
                    'description' : 'Bring up basic layout'
                 }
             }
        },
        'list2' : {
            'listTitle' : 'HOME',
            'cards' : {
                'card 1' : {
                    'title' : 'Maintain plants',
                    'description' : 'Water the plants'
                },
                'card 2' : {
                    'title' : 'Dinner Menu',
                    'description' : 'Prepare the Menu for dinner'
                }
               
            }

        },
        'list3' : {
            'listTitle' : 'OTHERS',
            'cards' : {
                'card 1' : {
                    'title' : 'Shopping',
                    'description' : 'Shop for kids'
                }
               
               
            }

        },
        
    
}